## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib kkmeans
#' @useDynLib kkmeans, .registration = TRUE
## usethis namespace: end
NULL
