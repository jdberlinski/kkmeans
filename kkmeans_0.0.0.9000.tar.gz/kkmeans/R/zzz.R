.onUnLoad <- function(libpath) {
  library.dynam.unload("kkmeans", libpath)
}
