## usethis namespace: start
#' @useDynLib kkmeans
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
