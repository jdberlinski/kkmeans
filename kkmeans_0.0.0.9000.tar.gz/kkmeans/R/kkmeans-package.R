## usethis namespace: start
#' @useDynLib kkmeans, .registration = TRUE
#' @importFrom Rcpp sourceCpp
## usethis namespace: end
NULL
